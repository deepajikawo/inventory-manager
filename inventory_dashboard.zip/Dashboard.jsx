import { useEffect, useState } from "react";
import { db } from "./firebaseConfig";
import { ref, onValue } from "firebase/database";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { PieChart, Pie, Cell } from "recharts";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, MessageSquare } from "lucide-react";

export default function Dashboard() {
  const [inventory, setInventory] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [chat, setChat] = useState([]);

  useEffect(() => {
    const inventoryRef = ref(db, "inventory");
    onValue(inventoryRef, (snapshot) => {
      setInventory(Object.entries(snapshot.val() || {}).map(([key, value]) => ({ name: key, ...value })));
    });
    
    const transactionsRef = ref(db, "transactions");
    onValue(transactionsRef, (snapshot) => {
      setTransactions(Object.values(snapshot.val() || {}));
    });
    
    const notificationsRef = ref(db, "low_stock_alerts");
    onValue(notificationsRef, (snapshot) => {
      setNotifications(Object.values(snapshot.val() || {}));
    });
    
    const chatRef = ref(db, "chat");
    onValue(chatRef, (snapshot) => {
      setChat(Object.values(snapshot.val() || {}));
    });
  }, []);

  return (
    <div className="p-6 grid grid-cols-3 gap-4">
      <Card className="col-span-2 p-4">
        <h2 className="text-xl font-bold">📊 Inventory Overview</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={inventory}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="stockQuantity" fill="#4CAF50" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card className="p-4">
        <h2 className="text-xl font-bold">⚠️ Notifications</h2>
        {notifications.map((alert, index) => (
          <div key={index} className="bg-red-100 p-2 my-2 rounded">{alert.productName} is low on stock!</div>
        ))}
      </Card>

      <Card className="col-span-2 p-4">
        <h2 className="text-xl font-bold">📈 Sales Trend</h2>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={transactions} dataKey="quantitySold" nameKey="productName" fill="#8884d8">
              {transactions.map((entry, index) => (
                <Cell key={index} fill={["#FF6384", "#36A2EB", "#FFCE56"][index % 3]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </Card>

      <Card className="p-4">
        <h2 className="text-xl font-bold">💬 Chat</h2>
        {chat.map((message, index) => (
          <div key={index} className="bg-gray-200 p-2 my-2 rounded">{message.user}: {message.message}</div>
        ))}
      </Card>
    </div>
  );
}
