import { useEffect, useState } from "react";
import { db } from "./firebase/firebaseConfig";
import { ref, onValue } from "firebase/database";
import InventoryChart from "./components/InventoryChart";
import SalesChart from "./components/SalesChart";
import Notifications from "./components/Notifications";
import Chat from "./components/Chat";
import InventoryManager from "./components/InventoryManager";
import SalesTransaction from "./components/SalesTransaction";

export default function Dashboard() {
  const [inventory, setInventory] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [chat, setChat] = useState([]);

  useEffect(() => {
    onValue(ref(db, "inventory"), (snapshot) => setInventory(Object.entries(snapshot.val() || {}).map(([key, value]) => ({ id: key, ...value }))));
    onValue(ref(db, "transactions"), (snapshot) => setTransactions(Object.values(snapshot.val() || {})));
    onValue(ref(db, "low_stock_alerts"), (snapshot) => setNotifications(Object.values(snapshot.val() || {})));
    onValue(ref(db, "chat"), (snapshot) => setChat(Object.values(snapshot.val() || {})));
  }, []);

  return (
    <div className="p-6 grid grid-cols-3 gap-4">
      <InventoryManager inventory={inventory} />
      <SalesTransaction />
      <InventoryChart data={inventory} />
      <Notifications alerts={notifications} />
      <SalesChart data={transactions} />
      <Chat messages={chat} />
    </div>
  );
}