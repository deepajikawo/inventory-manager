import Dashboard from "./Dashboard";

export default function App() {
  return (
    <div className="flex">
      <Dashboard />
    </div>
  );
}