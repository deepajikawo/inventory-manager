export default function Chat({ messages }) {
  return (
    <div className="p-4 bg-gray-200 rounded">
      <h2 className="text-xl font-bold">💬 Chat</h2>
      {messages.map((message, index) => (
        <div key={index} className="p-2 my-2 rounded">{message.user}: {message.message}</div>
      ))}
    </div>
  );
}