import { useState } from "react";
import { db } from "../firebase/firebaseConfig";
import { ref, push } from "firebase/database";

export default function SalesTransaction() {
  const [transaction, setTransaction] = useState({ productName: "", quantitySold: 0 });

  const handleSubmit = () => {
    if (transaction.productName && transaction.quantitySold) {
      push(ref(db, "transactions"), transaction);
      setTransaction({ productName: "", quantitySold: 0 });
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-xl font-bold">💰 Record Sales Transaction</h2>
      <input type="text" placeholder="Product Name" className="border p-2 m-2" value={transaction.productName} onChange={(e) => setTransaction({ ...transaction, productName: e.target.value })} />
      <input type="number" placeholder="Quantity Sold" className="border p-2 m-2" value={transaction.quantitySold} onChange={(e) => setTransaction({ ...transaction, quantitySold: Number(e.target.value) })} />
      <button onClick={handleSubmit} className="bg-green-500 text-white p-2 rounded">Record Sale</button>
    </div>
  );
}