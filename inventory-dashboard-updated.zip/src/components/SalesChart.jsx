import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

export default function SalesChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie data={data} dataKey="quantitySold" nameKey="productName" fill="#8884d8">
          {data.map((entry, index) => (
            <Cell key={index} fill={["#FF6384", "#36A2EB", "#FFCE56"][index % 3]} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );
}