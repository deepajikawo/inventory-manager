import { Bell, MessageSquare } from "lucide-react";

export default function Sidebar() {
  return (
    <div className="w-1/5 p-4 bg-gray-800 text-white h-screen">
      <h2 className="text-lg font-bold">Dashboard</h2>
      <ul>
        <li className="my-2 flex items-center"><Bell className="mr-2" /> Notifications</li>
        <li className="my-2 flex items-center"><MessageSquare className="mr-2" /> Chat</li>
      </ul>
    </div>
  );
}