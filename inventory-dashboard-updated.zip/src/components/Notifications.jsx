export default function Notifications({ alerts }) {
  return (
    <div className="p-4 bg-red-100 rounded">
      <h2 className="text-xl font-bold">⚠️ Notifications</h2>
      {alerts.map((alert, index) => (
        <div key={index} className="p-2 my-2 rounded">{alert.productName} is low on stock!</div>
      ))}
    </div>
  );
}