import { useState } from "react";
import { db } from "../firebase/firebaseConfig";
import { ref, push, update, remove } from "firebase/database";

export default function InventoryManager({ inventory }) {
  const [product, setProduct] = useState({ name: "", stockQuantity: 0 });

  const handleAdd = () => {
    if (product.name && product.stockQuantity) {
      push(ref(db, "inventory"), product);
      setProduct({ name: "", stockQuantity: 0 });
    }
  };

  const handleUpdate = (id, updatedStock) => {
    update(ref(db, `inventory/${id}`), { stockQuantity: updatedStock });
  };

  const handleDelete = (id) => {
    remove(ref(db, `inventory/${id}`));
  };

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-xl font-bold">📦 Manage Inventory</h2>
      <input type="text" placeholder="Product Name" className="border p-2 m-2" value={product.name} onChange={(e) => setProduct({ ...product, name: e.target.value })} />
      <input type="number" placeholder="Stock Quantity" className="border p-2 m-2" value={product.stockQuantity} onChange={(e) => setProduct({ ...product, stockQuantity: Number(e.target.value) })} />
      <button onClick={handleAdd} className="bg-green-500 text-white p-2 rounded">Add Product</button>

      <ul className="mt-4">
        {inventory.map((item) => (
          <li key={item.id} className="flex justify-between p-2 border-b">
            <span>{item.name} - {item.stockQuantity} in stock</span>
            <div>
              <button onClick={() => handleUpdate(item.id, item.stockQuantity + 1)} className="bg-blue-500 text-white p-1 mx-1">+1</button>
              <button onClick={() => handleUpdate(item.id, item.stockQuantity - 1)} className="bg-yellow-500 text-white p-1 mx-1">-1</button>
              <button onClick={() => handleDelete(item.id)} className="bg-red-500 text-white p-1 mx-1">Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}